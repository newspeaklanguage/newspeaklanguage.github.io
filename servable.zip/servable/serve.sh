#!/bin/sh -e
python ../server.py
